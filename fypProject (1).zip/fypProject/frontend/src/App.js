import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./Sidebar"; // Import Sidebar
import Home from "./Home"; // Import Home component
import SignUp from "./SignUp"; // Import Sign Up page
import Login from "./Login"; // Import Login page
import NewsFeed from "./components/NewsFeed"; // Import NewsFeed component
import SavedInteractions from "./components/SavedInteractions";
import Account from "./Account";
import UserRecommendations from "./components/UserRecommendations";
import PersonalizedNews from "./components/PersonalizedNews";

const App = () => {
  return (
    <Router>
      <div>
        <Sidebar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/news/:category" element={<NewsFeed />} />
          <Route path="/interest" element={<SavedInteractions />} />
          <Route path="/saved" element={<SavedInteractions />} />
          <Route path="/account" element={<Account />} />
          <Route path="/recommend" element={<UserRecommendations />} />
          <Route path="/personal" element={<PersonalizedNews />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
