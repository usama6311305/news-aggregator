import React, { useState, useEffect } from "react";
import {
  Box,
  Avatar,
  Typography,
  Button,
  TextField,
  Stack,
  Paper,
} from "@mui/material";

const Account = () => {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("user")));
  const [newPassword, setNewPassword] = useState("");
  const [profilePic, setProfilePic] = useState(user?.profilePic || null);
  const [imageFile, setImageFile] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser(storedUser);
      setProfilePic(storedUser.profilePic || null);
    }
  }, []);

  const handlePasswordChange = async () => {
    if (!newPassword) return alert("Enter a new password");

    try {
      const response = await fetch("http://localhost:5000/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, newPassword }),
      });

      const data = await response.json();
      if (response.ok) {
        alert("Password updated successfully");
        setNewPassword("");
      } else {
        alert(data.message || "Error updating password");
      }
    } catch (err) {
      console.error("Password change error:", err);
      alert("Something went wrong");
    }
  };

  const handleProfilePicUpload = async () => {
    if (!imageFile) return alert("No file selected");

    const formData = new FormData();
    formData.append("profilePic", imageFile);
    formData.append("userId", user.id);

    try {
      const response = await fetch("http://localhost:5000/api/auth/upload-profile-pic", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      if (response.ok) {
        const updatedUser = { ...user, profilePic: data.imageUrl };
        localStorage.setItem("user", JSON.stringify(updatedUser));
        setUser(updatedUser);
        setProfilePic(data.imageUrl);
        alert("Profile picture uploaded successfully");
      } else {
        alert(data.message || "Upload failed");
      }
    } catch (err) {
      console.error("Upload error:", err);
      alert("Something went wrong while uploading");
    }
  };

  if (!user) {
    return <Typography variant="h6" align="center">Please log in to view your account.</Typography>;
  }

  return (
    <Box sx={{ maxWidth: 600, mx: "auto", mt: 5 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Stack spacing={2} alignItems="center">
          <Avatar
            sx={{ width: 100, height: 100 }}
            src={
              profilePic
                ? profilePic.startsWith("http")
                  ? profilePic
                  : `http://localhost:5000${profilePic}`
                : "https://via.placeholder.com/100"
            }
            alt="Profile"
          />
          <Button variant="outlined" component="label">
            Upload Picture
            <input
              type="file"
              hidden
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  setImageFile(file);
                  setProfilePic(URL.createObjectURL(file)); // preview only
                }
              }}
            />
          </Button>
          {imageFile && (
            <Button variant="contained" onClick={handleProfilePicUpload}>
              Save Profile Picture
            </Button>
          )}

          <Typography variant="h5">{user.username}</Typography>
          <Typography color="text.secondary">{user.email}</Typography>

          <TextField
            label="New Password"
            type="password"
            fullWidth
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
          <Button variant="contained" color="primary" onClick={handlePasswordChange}>
            Change Password
          </Button>
        </Stack>
      </Paper>
    </Box>
  );
};

export default Account;
