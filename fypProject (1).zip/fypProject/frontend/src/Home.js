import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Home.css";
import NewsFeed from "./components/NewsFeed";
import { Button, Typography, Stack, Box } from '@mui/material';
// import SavedInteractions from "./components/SavedInteractions";
import PersonalizedNews from "./components/PersonalizedNews";

const Home = () => {
  const user = localStorage.getItem("user");
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("userId");
    localStorage.removeItem("userInterests");
    navigate("/login");
  };

  return (
    <div className="home-container">
      {/* Sidebar */}
      <div className="sidebar">
        <h2 className="brand-name">NewsSnap</h2>
        <ul className="nav-list">
          <li><Link to="/general">General</Link></li>
          <li><Link to="/sports">Sports</Link></li>
          <li><Link to="/business">Business</Link></li>
          <li><Link to="/trending">Trending</Link></li>
          <li><Link to="/technology">Technology</Link></li>
          <li><Link to="/health">Health</Link></li>
          <li><Link to="/entertainment">Entertainment</Link></li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header className="top-bar">
          <h1>Welcome to NewsSnap</h1>
          {user ? (
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 2 }}>
      <Typography variant="h6" sx={{ fontWeight: 'bold', display: 'flex', alignItems: 'center' }}>
        👤 {user.username}
      </Typography>
      
      <Stack direction="row" spacing={2}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => navigate("/account")}
          sx={{ textTransform: 'none' }}
        >
          Profile
        </Button>

        <Button
          variant="outlined"
          color="secondary"
          onClick={handleLogout}
          sx={{ textTransform: 'none', borderRadius: 3 }}
        >
          Logout
        </Button>
      </Stack>
    </Box>
          ) : (
            <div>
              <Link to="/signup" className="signup-button">Sign Up</Link>
              <Link to="/login" className="login-button">Login</Link>
            </div>
          )}
        </header>

        <div className="content-area">
          <PersonalizedNews/>
          <NewsFeed />
        </div>
      </div>
    </div>
  );
};

export default Home;  
