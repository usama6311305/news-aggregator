import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Grid,
  Button
} from "@mui/material";

const SavedInteractions = () => {
  const [interactions, setInteractions] = useState([]);
  const [loading, setLoading] = useState(true);
  const userId = localStorage.getItem("userId");

useEffect(() => {
  if (!userId) {
    alert("User not logged in");
    return;
  }

  fetch(`http://localhost:5000/api/interactions/user/${userId}`)
    .then((res) => res.json())
    .then((data) => {
      setInteractions(data.interactions || []); // ✅ Fix here
      setLoading(false);
    })
    .catch((err) => {
      console.error("Error fetching interactions:", err);
      setLoading(false);
    });
}, [userId]);

  if (loading) {
    return <Typography align="center" variant="h6">Loading saved interactions...</Typography>;
  }

  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4" align="center" gutterBottom>
        Your Saved Interactions
      </Typography>
      <Grid container spacing={3}>
        {interactions.length === 0 ? (
          <Typography variant="body1" align="center" color="textSecondary">
            No interactions found.
          </Typography>
        ) : (
          interactions.map((interaction, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              
              <Card sx={{ maxWidth: 345, height: "100%", display: "flex", flexDirection: "column" }}>
                <CardMedia
                  component="img"
                  height="180"
                  image={interaction.article.urlToImage || "https://via.placeholder.com/300"}
                  alt={interaction.article.title}
                />
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography variant="h6" gutterBottom>{interaction.article.title}</Typography>
                  <Typography variant="body2" color="textSecondary">{interaction.article.description}</Typography>
                </CardContent>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => window.open(interaction.article.url, "_blank")}
                  sx={{ margin: "10px" }}
                >
                  Read Again
                </Button>
              </Card>
            </Grid>
          ))
        )}
      </Grid>
    </div>
  );
};

export default SavedInteractions;
