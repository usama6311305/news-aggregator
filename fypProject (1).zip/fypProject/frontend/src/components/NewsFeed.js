import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Grid,
} from "@mui/material";

const NewsFeed = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const { category } = useParams();
  const selectedCategory = category || "general";

  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`http://localhost:5000/api/news?category=${selectedCategory}`)
      .then((response) => response.json())
      .then((data) => {
        console.log("Fetched data:", data);
        setArticles(data.articles || []);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching news:", error);
        setLoading(false);
      });
  }, [selectedCategory]);

  const handleReadMore = (article) => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      alert("User not logged in.");
      return;
    }

    // Save the user interaction
    fetch("http://localhost:5000/api/interactions/save-interaction", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId,
        category: selectedCategory,
        article,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log("Interaction saved:", data);
        // Open article after saving interaction
        window.open(article.url, "_blank");
      })
      .catch((err) => {
        console.error("Error saving interaction:", err);
        // Still open article even if saving fails
        window.open(article.url, "_blank");
      });
  };

  if (loading) {
    return (
      <Typography variant="h5" align="center">
        Loading...
      </Typography>
    );
  }
const filteredArticles = articles.filter(
  (article) =>
    article.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.description?.toLowerCase().includes(searchTerm.toLowerCase())
);
  return (
    <div style={{ padding: "20px" }}>
      <Typography variant="h4" align="center" gutterBottom>
        {selectedCategory.toUpperCase()} News
      </Typography>
      <div style={{ marginBottom: "20px", textAlign: "center" }}>
  <input
    type="text"
    placeholder="Search articles..."
    value={searchTerm}
    onChange={(e) => setSearchTerm(e.target.value)}
    style={{
      width: "80%",
      padding: "10px",
      fontSize: "16px",
      borderRadius: "4px",
      border: "1px solid #ccc",
    }}
  />
</div>

      <Grid container spacing={3}>
        {filteredArticles.map((article, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Card
              sx={{
                maxWidth: 345,
                height: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <CardMedia
                component="img"
                height="180"
                image={article.urlToImage || "https://via.placeholder.com/300"}
                alt={article.title}
              />
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography variant="h6" gutterBottom>
                  {article.title}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  {article.description}
                </Typography>
              </CardContent>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleReadMore(article)}
                sx={{ margin: "10px" }}
              >
                Read More
              </Button>
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
};

export default NewsFeed;
