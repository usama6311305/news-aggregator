import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  CardMedia,
  Button,
  Divider,
  CircularProgress,
} from "@mui/material";

const PersonalizedNews = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  const [news, setNews] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPersonalizedNews = async () => {
      try {
        const res = await fetch(`http://localhost:5000/api/interactions/user/${user.id}/news`);
        const data = await res.json();
        setNews(data);
      } catch (err) {
        console.error("Failed to load news:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchPersonalizedNews();
  }, [user.id]);

  if (loading) {
    return (
      <Box sx={{ p: 4, textAlign: "center" }}>
        <CircularProgress />
        <Typography mt={2}>Loading personalized news...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>
        Your Personalized News
      </Typography>
      {Object.keys(news).length === 0 ? (
        <Typography>No personalized news available.</Typography>
      ) : (
        Object.entries(news).map(([category, articles]) => (
          <Box key={category} sx={{ mt: 4 }}>
            <Typography variant="h5" sx={{ textTransform: "capitalize" }}>
              {category}
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              {articles.map((article, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
                    {article.urlToImage && (
                      <CardMedia
                        component="img"
                        height="180"
                        image={article.urlToImage}
                        alt={article.title}
                      />
                    )}
                    <CardContent sx={{ flexGrow: 1 }}>
                      <Typography variant="h6" gutterBottom>
                        {article.title}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {article.description?.slice(0, 100)}...
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Button
                        size="small"
                        href={article.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Read More
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        ))
      )}
    </Box>
  );
};

export default PersonalizedNews;
