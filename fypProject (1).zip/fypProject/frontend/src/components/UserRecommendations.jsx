import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  CardActions,
  Button,
  Grid,
  Divider,
} from "@mui/material";

const UserRecommendations = () => {
  const [groupedInteractions, setGroupedInteractions] = useState({});
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    const fetchInteractions = async () => {
      try {
        const res = await fetch(
          `http://localhost:5000/api/interactions/user/${user.id}/interactions-grouped`
        );
        const data = await res.json();
        setGroupedInteractions(data.groupedInteractions || {});
      } catch (error) {
        console.error("Error fetching interactions:", error);
      }
    };

    if (user) fetchInteractions();
  }, [user]);

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>
        Your Personalized News
      </Typography>
      {Object.keys(groupedInteractions).length === 0 ? (
        <Typography>No saved interactions found.</Typography>
      ) : (
        Object.entries(groupedInteractions).map(([category, articles]) => (
          <Box key={category} sx={{ mt: 4 }}>
            <Typography variant="h5" gutterBottom sx={{ textTransform: "capitalize" }}>
              {category} News
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              {articles.map((interaction, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
                    <CardContent>
                      <Typography variant="h6">
                        {interaction.article.title}
                      </Typography>
                      {interaction.article.description && (
                        <Typography variant="body2" color="text.secondary">
                          {interaction.article.description.slice(0, 100)}...
                        </Typography>
                      )}
                    </CardContent>
                    <CardActions>
                      <Button
                        size="small"
                        href={interaction.article.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Read More
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        ))
      )}
    </Box>
  );
};

export default UserRecommendations;
