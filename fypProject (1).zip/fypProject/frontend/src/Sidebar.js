import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Sidebar.css";

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  // Function to close the sidebar when a category is clicked
  const closeSidebar = () => {
    setIsOpen(false);
  };

  return (
    <div>
      <header className="header">
        <button className="toggle-button" onClick={toggleSidebar}>
          {isOpen ? "✖" : "☰"}
        </button>
        <h1 className="news-name">NewsSnap</h1>
        <Link to="/signup" className="signup-header-button">
          Sign Up
        </Link>
      </header>

      <div className={`sidebar ${isOpen ? "open" : "closed"}`}>
        <ul className="nav-list">
          <li><Link to="/" onClick={closeSidebar}>Home</Link></li>
          <li><Link to="/news/general" onClick={closeSidebar}>General</Link></li>
          <li><Link to="/news/sports" onClick={closeSidebar}>Sports</Link></li>
          <li><Link to="/news/business" onClick={closeSidebar}>Business</Link></li>
          <li><Link to="/news/trending" onClick={closeSidebar}>Trending</Link></li>
          <li><Link to="/news/technology" onClick={closeSidebar}>Technology</Link></li>
          <li><Link to="/news/health" onClick={closeSidebar}>Health</Link></li>
          <li><Link to="/news/entertainment" onClick={closeSidebar}>Entertainment</Link></li>
          <li><Link to="/news/science" onClick={closeSidebar}>Science</Link></li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
