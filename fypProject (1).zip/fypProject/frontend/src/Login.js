import React, { useState } from "react";
import { TextField, Button, Box, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await response.json();
      if (response.ok) {
        alert("Login Successful!");
        console.log("Token:", data.token); // You can save the token to localStorage
        localStorage.setItem("userId", data.user.id);
localStorage.setItem("user", JSON.stringify(data.user)); // This line is important

        
        // Fetch user's interests (categories they interacted with)
        const interestsResponse = await fetch(`http://localhost:5000/api/interactions/user/${data.user.id}/interests`);
        const interestsData = await interestsResponse.json();
        if (interestsResponse.ok) {
          localStorage.setItem("userInterests", JSON.stringify(interestsData.interests));
        }
        
        navigate("/"); // Navigate to home page
      } else {
        alert(data.message || "Something went wrong");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to login");
    }
  };
  

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 2,
        maxWidth: 400,
        margin: "auto",
        mt: 25,
        p: 3,
        border: "1px solid #ccc",
        borderRadius: 4,
      }}
    >
      <Typography variant="h4" component="h1" gutterBottom>
        Login
      </Typography>
      <TextField
        type="email"
        name="email"
        label="Email"
        variant="outlined"
        fullWidth
        onChange={handleChange}
        required
      />
      <TextField
        type="password"
        name="password"
        label="Password"
        variant="outlined"
        fullWidth
        onChange={handleChange}
        required
      />
      <Button type="submit" variant="contained" color="primary" fullWidth>
        Login
      </Button>
    </Box>
  );
};

export default Login; 
