const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./Routes/auth');
const NewsAPI = require('newsapi');
const newsapi = new NewsAPI('5a4d4277875e457f961063d72b04dd28');
const interactionRoutes = require('./Routes/interactions');
const path = require("path");

require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());
app.use(cors({ origin: 'http://localhost:3000' }));
// app.use('/uploads', express.static('uploads'));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
// Database Connection
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/fypproject';

mongoose.connect(MONGODB_URI);

const db = mongoose.connection;

// Event Listeners for the Connection
db.on('error', (error) => console.error('MongoDB connection error:', error));
db.once('open', () => {
  console.log('Connected to MongoDB');
  // Routes
  
  app.use('/api/interactions', interactionRoutes);
  app.use('/api/auth', authRoutes);
  app.use("/uploads", express.static("uploads"));

  app.get('/api/news', async (req, res) => {
    try {
      const category = req.query.category || 'general'; // Default to 'general'
      const response = await newsapi.v2.topHeadlines({
        category: category, // Use the category from the frontend
        language: 'en',
        country: 'us',
        });
        
        console.log(`Fetching news for category: ${category}`);
        res.json(response); // Send response to frontend
      } catch (error) {
        console.error("Error fetching news:", error);
        res.status(500).send({ error: error.message });
      }
    });
    

 
  // Start the server after successful connection
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
});