const express = require('express');
const router = express.Router();
const UserInteraction = require('../Models/UserInteraction');
const axios = require("axios");
// Save user interaction
router.post('/save-interaction', async (req, res) => {
  const { userId, category, article } = req.body;

  try {
    const newInteraction = new UserInteraction({ userId, category, article });
    await newInteraction.save();
    res.status(200).json({ message: "Interaction saved successfully" });
  } catch (err) {
    console.error("Error saving interaction:", err);
    res.status(500).json({ error: err.message });
  }
});

// Get user interactions grouped by category (max 3 articles per category)
router.get('/user/:userId/interactions-grouped', async (req, res) => {
  const { userId } = req.params;

  try {
    const interactions = await UserInteraction.find({ userId });

    // Grouping logic
    const grouped = {};
    for (const interaction of interactions) {
      const category = interaction.category;

      if (!grouped[category]) {
        grouped[category] = [];
      }

      // Avoid duplicate articles and limit to 3
      if (!grouped[category].some(i => i.article.url === interaction.article.url)) {
        if (grouped[category].length < 3) {
          grouped[category].push(interaction);
        }
      }
    }

    res.status(200).json({ groupedInteractions: grouped });
  } catch (err) {
    console.error("Error fetching grouped interactions:", err);
    res.status(500).json({ error: err.message });
  }
});


// Fetch user interests (categories) based on their interactions
router.get('/user-interests', async (req, res) => {
    const { userId } = req.query;
    
    try {
      // Find the distinct categories the user has interacted with
      const userInteractions = await UserInteraction.distinct('category', { userId });
      
      if (userInteractions.length === 0) {
        return res.status(200).json({ message: 'No interactions found', interests: [] });
      }
      
      res.status(200).json({ interests: userInteractions });
    } catch (err) {
      console.error("Error fetching user interests:", err);
      res.status(500).json({ error: err.message });
    }
  });
  
  router.get('/user/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    const interactions = await UserInteraction.find({ userId });
    res.status(200).json({ interactions });
  } catch (err) {
    console.error("Error fetching user interactions:", err);
    res.status(500).json({ error: err.message });
  }
});


router.get('/user/:userId/interests', async (req, res) => {
  const { userId } = req.params;

  try {
    const userInteractions = await UserInteraction.distinct('category', { userId });

    if (userInteractions.length === 0) {
      return res.status(200).json({ message: 'No interactions found', interests: [] });
    }

    res.status(200).json({ interests: userInteractions });
  } catch (err) {
    console.error("Error fetching user interests:", err);
    res.status(500).json({ error: err.message });
  }
});

// In routes/interactions.js


router.get("/user/:userId/news", async (req, res) => {
  const { userId } = req.params;
  const NEWS_API_KEY = "5a4d4277875e457f961063d72b04dd28"; // Replace this

  try {
    const categories = await UserInteraction.distinct("category", { userId });
    const newsByCategory = {};

    for (const category of categories) {
      const response = await axios.get(
        `https://newsapi.org/v2/top-headlines?category=${category}&pageSize=3&country=us&apiKey=${NEWS_API_KEY}`
      );
      newsByCategory[category] = response.data.articles || [];
    }

    res.status(200).json(newsByCategory);
  } catch (err) {
    console.error("Error fetching user news:", err);
    res.status(500).json({ message: "Failed to fetch news", error: err.message });
  }
});


module.exports = router;
